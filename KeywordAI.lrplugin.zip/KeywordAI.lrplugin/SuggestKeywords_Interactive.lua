local LrApplication = import "LrApplication"
local LrDialogs = import "LrDialogs"
local LrPathUtils = import "LrPathUtils"
local LrTasks = import "LrTasks"
local LrView = import "LrView"
local LrBinding = import "LrBinding"
local LrFunctionContext = import "LrFunctionContext"

local scriptPath = LrPathUtils.child(
    LrPathUtils.child(LrPathUtils.getStandardFilePath("home"), "LightroomAI"),
    "suggest_keywords.py"
)

local function showKeywordDialog(catalog, photo, index, total)
    local photoPath = photo:getRawMetadata("path")
    local filename = LrPathUtils.leafName(photoPath)
    local command = 'python3 "' .. scriptPath .. '" "' .. photoPath .. '"'
    local handle = io.popen(command)
    local result = handle:read("*a")
    handle:close()
    result = result:match("^%s*(.-)%s*$")
    local keywords = {}
    for kw in result:gmatch("[^,]+") do
        kw = kw:match("^%s*(.-)%s*$")
        if kw and #kw > 0 then
            table.insert(keywords, kw)
        end
    end
    if #keywords == 0 then
        LrDialogs.message("KeywordAI", "No keywords returned for " .. filename, "warning")
        return
    end
    local applied = 0
    LrFunctionContext.callWithContext("KeywordDialog", function(context)
        local f = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)
        for i = 1, #keywords do
            props["kw_" .. i] = true
        end
        local rows = {
            spacing = f:dialog_spacing(),
            bind_to_object = props,
            f:static_text {
                title = "Photo " .. index .. " of " .. total .. ": " .. filename,
                font = "<system/bold>",
            },
            f:static_text { title = "Tick the keywords you want to apply:" },
        }
        for i, kw in ipairs(keywords) do
            rows[#rows + 1] = f:checkbox {
                title = kw,
                value = LrView.bind("kw_" .. i),
            }
        end
        rows[#rows + 1] = f:row {
            f:push_button {
                title = "Select All",
                action = function()
                    for i = 1, #keywords do props["kw_" .. i] = true end
                end,
            },
            f:push_button {
                title = "Select None",
                action = function()
                    for i = 1, #keywords do props["kw_" .. i] = false end
                end,
            },
        }
        local contents = f:column(rows)
        local result2 = LrDialogs.presentModalDialog {
            title = "KeywordAI Suggested Keywords",
            contents = contents,
            actionVerb = "Apply",
            cancelVerb = "Skip",
        }
        if result2 == "ok" then
            local selected = {}
            for i, kw in ipairs(keywords) do
                if props["kw_" .. i] then
                    table.insert(selected, kw)
                end
            end
            if #selected > 0 then
                catalog:withWriteAccessDo("Add AI Keywords", function()
                    for _, kw in ipairs(selected) do
                        local kwObj = catalog:createKeyword(kw, {}, false, nil, true)
                        photo:addKeyword(kwObj)
                    end
                end)
                applied = #selected
            end
        end
    end)
    if applied > 0 then
        LrDialogs.message("KeywordAI", applied .. " keywords added to " .. filename, "info")
    end
end

LrTasks.startAsyncTask(function()
    local catalog = LrApplication.activeCatalog()
    local photos = catalog:getTargetPhotos()
    if #photos == 0 then
        LrDialogs.message("KeywordAI", "Please select at least one photo first.", "info")
        return
    end
    for i, photo in ipairs(photos) do
        local filename = LrPathUtils.leafName(photo:getRawMetadata("path"))
        LrDialogs.message("KeywordAI", "Analysing " .. i .. " of " .. #photos .. ": " .. filename, "info")
        showKeywordDialog(catalog, photo, i, #photos)
    end
    LrDialogs.message("KeywordAI", "All done! Processed " .. #photos .. " photo(s).", "info")
end)

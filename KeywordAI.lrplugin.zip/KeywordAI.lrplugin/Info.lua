return {
    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 5.0,
    LrToolkitIdentifier = "com.lightroomai.keywordai",
    LrPluginName = "KeywordAI",
    LrPluginInfoUrl = "",
    LrAuthor = "Rob Durston & Claude (Anthropic)",
    LrInitPlugin = nil,
    LrLibraryMenuItems = {
        {
            title = "Suggest Keywords (Review and Select)",
            file = "SuggestKeywords_Interactive.lua",
        },
        {
            title = "Suggest Keywords (Auto, No Prompts)",
            file = "SuggestKeywords_Auto.lua",
        },
    },
    VERSION = { major=1, minor=0, revision=0 },
}

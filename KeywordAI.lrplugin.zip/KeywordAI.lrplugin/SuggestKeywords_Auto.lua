local LrApplication = import "LrApplication"
local LrDialogs = import "LrDialogs"
local LrPathUtils = import "LrPathUtils"
local LrTasks = import "LrTasks"
local LrProgressScope = import "LrProgressScope"

local scriptPath = LrPathUtils.child(
    LrPathUtils.child(LrPathUtils.getStandardFilePath("home"), "LightroomAI"),
    "suggest_keywords.py"
)

LrTasks.startAsyncTask(function()
    local catalog = LrApplication.activeCatalog()
    local photos = catalog:getTargetPhotos()

    if #photos == 0 then
        LrDialogs.message("KeywordAI", "Please select at least one photo first.", "info")
        return
    end

    local progress = LrProgressScope {
        title = "KeywordAI: Analysing " .. #photos .. " photo(s)...",
        functionContext = nil,
    }

    local totalAdded = 0

    for i, photo in ipairs(photos) do
        if progress:isCanceled() then break end

        local photoPath = photo:getRawMetadata("path")
        local filename = LrPathUtils.leafName(photoPath)

        progress:setCaption("Analysing " .. i .. " of " .. #photos .. ": " .. filename)
        progress:setPortionComplete(i - 1, #photos)

        local command = 'python3 "' .. scriptPath .. '" "' .. photoPath .. '"'
        local handle = io.popen(command)
        local result = handle:read("*a")
        handle:close()

        result = result:match("^%s*(.-)%s*$")

        local keywords = {}
        for kw in result:gmatch("[^,]+") do
            kw = kw:match("^%s*(.-)%s*$")
            if kw and #kw > 0 then
                table.insert(keywords, kw)
            end
        end

        if #keywords > 0 then
            catalog:withWriteAccessDo("Add AI Keywords", function()
                for _, kw in ipairs(keywords) do
                    local kwObj = catalog:createKeyword(kw, {}, false, nil, true)
                    photo:addKeyword(kwObj)
                end
            end)
            totalAdded = totalAdded + #keywords
        end
    end

    progress:done()
    LrDialogs.message("KeywordAI", "Done! Processed " .. #photos .. " photo(s).\nTotal keywords added: " .. totalAdded, "info")
end)
